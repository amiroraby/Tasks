
class Library:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.books = {}
        return cls._instance

    def add_book(self, name):
        self.books[name] = self.books.get(name, 0) + 1

    def remove_book(self, name):
        if name in self.books:
            del self.books[name]

    def list_books(self):
        return self.books


if __name__ == "__main__":
    lib = Library()
    lib.add_book("Python")
    print(lib.list_books())
