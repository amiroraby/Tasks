# SAD2 GitHub Portfolio

Student: Hamdy Emad Mamdouh Ahmed
Course: System Analysis and Design 2
