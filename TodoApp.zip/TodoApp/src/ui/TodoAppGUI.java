package ui;

import model.Task;
import model.TaskPriority;
import model.TaskStatus;
import service.TaskService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TodoAppGUI extends JFrame {
    private TaskService taskService;
    private JTable taskTable;
    private DefaultTableModel tableModel;
    private JTextField titleField, descriptionField;
    private JComboBox<TaskPriority> priorityCombo;
    private JFormattedTextField dueDateField;
    private JComboBox<TaskStatus> statusFilterCombo;
    
    public TodoAppGUI(TaskService taskService) {
        this.taskService = taskService;
        initComponents();
        setTitle("تطبيق إدارة المهام البسيط");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        loadTasks();
    }
    
    private void initComponents() {
        // تطبيق مبدأ Single Responsibility - كل جزء له وظيفة واحدة
        setLayout(new BorderLayout());
        
        // لوحة الإضافة
        JPanel addPanel = createAddPanel();
        add(addPanel, BorderLayout.NORTH);
        
        // جدول المهام
        JPanel tablePanel = createTablePanel();
        add(tablePanel, BorderLayout.CENTER);
        
        // لوحة التحكم
        JPanel controlPanel = createControlPanel();
        add(controlPanel, BorderLayout.SOUTH);
    }
    
    private JPanel createAddPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createTitledBorder("إضافة مهمة جديدة"));
        panel.setBackground(new Color(240, 240, 240));
        
        // حقول الإدخال
        panel.add(new JLabel("عنوان المهمة:"));
        titleField = new JTextField();
        panel.add(titleField);
        
        panel.add(new JLabel("الوصف:"));
        descriptionField = new JTextField();
        panel.add(descriptionField);
        
        panel.add(new JLabel("الأولوية:"));
        priorityCombo = new JComboBox<>(TaskPriority.values());
        panel.add(priorityCombo);
        
        panel.add(new JLabel("تاريخ الاستحقاق (yyyy-mm-dd):"));
        dueDateField = new JFormattedTextField(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        dueDateField.setText(LocalDate.now().plusDays(7).toString());
        panel.add(dueDateField);
        
        JButton addButton = new JButton("إضافة المهمة");
        addButton.setBackground(new Color(76, 175, 80));
        addButton.setForeground(Color.WHITE);
        addButton.addActionListener(e -> addTask());
        panel.add(addButton);
        
        return panel;
    }
    
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        // نموذج الجدول
        String[] columns = {"المعرف", "العنوان", "الوصف", "الأولوية", "الحالة", "تاريخ الاستحقاق"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // جعل الجدول للقراءة فقط
            }
        };
        
        taskTable = new JTable(tableModel);
        taskTable.setRowHeight(30);
        taskTable.setFont(new Font("Arial", Font.PLAIN, 14));
        
        JScrollPane scrollPane = new JScrollPane(taskTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createControlPanel() {
        JPanel panel = new JPanel(new FlowLayout());
        panel.setBackground(new Color(220, 220, 220));
        
        // زر تحديث الحالة
        JButton updateStatusButton = new JButton("تحديث حالة المهمة المحددة");
        updateStatusButton.setBackground(new Color(33, 150, 243));
        updateStatusButton.setForeground(Color.WHITE);
        updateStatusButton.addActionListener(e -> updateTaskStatus());
        panel.add(updateStatusButton);
        
        // زر حذف
        JButton deleteButton = new JButton("حذف المهمة المحددة");
        deleteButton.setBackground(new Color(244, 67, 54));
        deleteButton.setForeground(Color.WHITE);
        deleteButton.addActionListener(e -> deleteTask());
        panel.add(deleteButton);
        
        // تصفية حسب الحالة
        panel.add(new JLabel("تصفية حسب الحالة:"));
        statusFilterCombo = new JComboBox<>(TaskStatus.values());
        statusFilterCombo.addActionListener(e -> filterByStatus());
        panel.add(statusFilterCombo);
        
        // زر عرض الكل
        JButton showAllButton = new JButton("عرض جميع المهام");
        showAllButton.setBackground(new Color(255, 152, 0));
        showAllButton.setForeground(Color.WHITE);
        showAllButton.addActionListener(e -> loadTasks());
        panel.add(showAllButton);
        
        // زر المهام عالية الأولوية
        JButton highPriorityButton = new JButton("عرض المهام عالية الأولوية");
        highPriorityButton.setBackground(new Color(156, 39, 176));
        highPriorityButton.setForeground(Color.WHITE);
        highPriorityButton.addActionListener(e -> showHighPriorityTasks());
        panel.add(highPriorityButton);
        
        return panel;
    }
    
    private void addTask() {
        try {
            String title = titleField.getText().trim();
            String description = descriptionField.getText().trim();
            TaskPriority priority = (TaskPriority) priorityCombo.getSelectedItem();
            LocalDate dueDate = LocalDate.parse(dueDateField.getText());
            
            if (title.isEmpty()) {
                JOptionPane.showMessageDialog(this, "الرجاء إدخال عنوان المهمة");
                return;
            }
            
            Task task = taskService.createTask(title, description, priority, dueDate);
            if (task != null) {
                loadTasks();
                clearInputFields();
                JOptionPane.showMessageDialog(this, "تم إضافة المهمة بنجاح!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "خطأ في إدخال البيانات: " + e.getMessage());
        }
    }
    
    private void loadTasks() {
        clearTable();
        List<Task> tasks = taskService.getAllTasks();
        for (Task task : tasks) {
            Object[] row = {
                task.getId(),
                task.getTitle(),
                task.getDescription(),
                task.getPriority().getArabicName(),
                task.getStatus().getArabicName(),
                task.getDueDate().toString()
            };
            tableModel.addRow(row);
        }
    }
    
    private void clearTable() {
        tableModel.setRowCount(0);
    }
    
    private void clearInputFields() {
        titleField.setText("");
        descriptionField.setText("");
        priorityCombo.setSelectedIndex(0);
        dueDateField.setText(LocalDate.now().plusDays(7).toString());
    }
    
    private void deleteTask() {
        int selectedRow = taskTable.getSelectedRow();
        if (selectedRow >= 0) {
            String taskId = (String) tableModel.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this, 
                "هل أنت متأكد من حذف هذه المهمة؟", 
                "تأكيد الحذف", 
                JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                boolean deleted = taskService.deleteTask(taskId);
                if (deleted) {
                    loadTasks();
                    JOptionPane.showMessageDialog(this, "تم حذف المهمة بنجاح");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "الرجاء تحديد مهمة للحذف");
        }
    }
    
    private void updateTaskStatus() {
        int selectedRow = taskTable.getSelectedRow();
        if (selectedRow >= 0) {
            String taskId = (String) tableModel.getValueAt(selectedRow, 0);
            TaskStatus[] statuses = TaskStatus.values();
            TaskStatus newStatus = (TaskStatus) JOptionPane.showInputDialog(
                this,
                "اختر الحالة الجديدة:",
                "تحديث حالة المهمة",
                JOptionPane.PLAIN_MESSAGE,
                null,
                statuses,
                statuses[0]
            );
            
            if (newStatus != null) {
                Task updated = taskService.updateTaskStatus(taskId, newStatus);
                if (updated != null) {
                    loadTasks();
                    JOptionPane.showMessageDialog(this, "تم تحديث حالة المهمة");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "الرجاء تحديد مهمة لتحديث حالتها");
        }
    }
    
    private void filterByStatus() {
        TaskStatus selectedStatus = (TaskStatus) statusFilterCombo.getSelectedItem();
        if (selectedStatus != null) {
            clearTable();
            List<Task> tasks = taskService.getTasksByStatus(selectedStatus);
            for (Task task : tasks) {
                Object[] row = {
                    task.getId(),
                    task.getTitle(),
                    task.getDescription(),
                    task.getPriority().getArabicName(),
                    task.getStatus().getArabicName(),
                    task.getDueDate().toString()
                };
                tableModel.addRow(row);
            }
        }
    }
    
    private void showHighPriorityTasks() {
        clearTable();
        List<Task> tasks = taskService.getHighPriorityTasks();
        for (Task task : tasks) {
            Object[] row = {
                task.getId(),
                task.getTitle(),
                task.getDescription(),
                task.getPriority().getArabicName(),
                task.getStatus().getArabicName(),
                task.getDueDate().toString()
            };
            tableModel.addRow(row);
        }
        JOptionPane.showMessageDialog(this, 
            "عُرضت " + tasks.size() + " مهمة عالية الأولوية");
    }
}