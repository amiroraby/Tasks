package model;

public enum TaskPriority {
    LOW("منخفض"),
    MEDIUM("متوسط"),
    HIGH("مرتفع");
    
    private final String arabicName;
    
    TaskPriority(String arabicName) {
        this.arabicName = arabicName;
    }
    
    public String getArabicName() {
        return arabicName;
    }
}