package model;

public enum TaskStatus {
    PENDING("قيد الانتظار"),
    IN_PROGRESS("قيد التنفيذ"),
    COMPLETED("مكتمل");
    
    private final String arabicName;
    
    TaskStatus(String arabicName) {
        this.arabicName = arabicName;
    }
    
    public String getArabicName() {
        return arabicName;
    }
}