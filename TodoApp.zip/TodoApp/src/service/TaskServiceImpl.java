package service;

import model.Task;
import model.TaskPriority;
import model.TaskStatus;
import repository.TaskRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class TaskServiceImpl implements TaskService {
    private final TaskRepository taskRepository;
    
    // تطبيق مبدأ Dependency Injection (DIP من SOLID)
    public TaskServiceImpl(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }
    
    @Override
    public Task createTask(String title, String description, TaskPriority priority, LocalDate dueDate) {
        Task task = new Task(null, title, description, priority, dueDate);
        return taskRepository.save(task);
    }
    
    @Override
    public Task getTask(String id) {
        return taskRepository.findById(id).orElse(null);
    }
    
    @Override
    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }
    
    @Override
    public boolean deleteTask(String id) {
        return taskRepository.delete(id);
    }
    
    @Override
    public Task updateTaskStatus(String id, TaskStatus status) {
        Task task = getTask(id);
        if (task != null) {
            task.setStatus(status);
            return taskRepository.update(task);
        }
        return null;
    }
    
    @Override
    public Task updateTask(String id, String title, String description, TaskPriority priority, LocalDate dueDate) {
        Task task = getTask(id);
        if (task != null) {
            task.setTitle(title);
            task.setDescription(description);
            task.setPriority(priority);
            task.setDueDate(dueDate);
            return taskRepository.update(task);
        }
        return null;
    }
    
    @Override
    public List<Task> getTasksByStatus(TaskStatus status) {
        return taskRepository.findByStatus(status.name());
    }
    
    @Override
    public List<Task> getHighPriorityTasks() {
        return taskRepository.findAll().stream()
                .filter(task -> task.getPriority() == TaskPriority.HIGH)
                .collect(Collectors.toList());
    }
}