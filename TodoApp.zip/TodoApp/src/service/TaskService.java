package service;

import model.Task;
import model.TaskPriority;
import model.TaskStatus;
import java.time.LocalDate;
import java.util.List;

public interface TaskService {
    Task createTask(String title, String description, TaskPriority priority, LocalDate dueDate);
    Task getTask(String id);
    List<Task> getAllTasks();
    boolean deleteTask(String id);
    Task updateTaskStatus(String id, TaskStatus status);
    Task updateTask(String id, String title, String description, TaskPriority priority, LocalDate dueDate);
    List<Task> getTasksByStatus(TaskStatus status);
    List<Task> getHighPriorityTasks();
}