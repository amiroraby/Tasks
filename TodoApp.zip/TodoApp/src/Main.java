import repository.InMemoryTaskRepository;
import service.TaskService;
import service.TaskServiceImpl;
import ui.TodoAppGUI;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        InMemoryTaskRepository repository = new InMemoryTaskRepository();
        TaskService taskService = new TaskServiceImpl(repository);
        

        SwingUtilities.invokeLater(() -> {
            TodoAppGUI app = new TodoAppGUI(taskService);
            app.setVisible(true);
        });
    }
}