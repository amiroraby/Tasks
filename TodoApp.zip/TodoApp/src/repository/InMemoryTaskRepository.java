package repository;

import model.Task;
import java.util.*;

public class InMemoryTaskRepository implements TaskRepository {
    private final Map<String, Task> tasks = new HashMap<>();
    private static int idCounter = 1;
    
    @Override
    public Task save(Task task) {
        if (task.getId() == null) {
            task = new Task("TASK-" + idCounter++, 
                           task.getTitle(), 
                           task.getDescription(), 
                           task.getPriority(), 
                           task.getDueDate());
        }
        tasks.put(task.getId(), task);
        return task;
    }
    
    @Override
    public Optional<Task> findById(String id) {
        return Optional.ofNullable(tasks.get(id));
    }
    
    @Override
    public List<Task> findAll() {
        return new ArrayList<>(tasks.values());
    }
    
    @Override
    public boolean delete(String id) {
        return tasks.remove(id) != null;
    }
    
    @Override
    public Task update(Task task) {
        if (tasks.containsKey(task.getId())) {
            tasks.put(task.getId(), task);
            return task;
        }
        return null;
    }
    
    @Override
    public List<Task> findByStatus(String status) {
        List<Task> filteredTasks = new ArrayList<>();
        for (Task task : tasks.values()) {
            if (task.getStatus().name().equalsIgnoreCase(status)) {
                filteredTasks.add(task);
            }
        }
        return filteredTasks;
    }
}